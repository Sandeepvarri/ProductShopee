import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  productId : number;
 productName : string;
  productDetails : string;
  productPrice: number;
  formdata;
  ControlId:FormControl;
  ControlNames:FormControl;
  ControlDetails:FormControl;
  ControlPrice:FormControl;
  constructor( ) {
   }
  ngOnInit() {
    //Service Fucntion
    this.productId = 1;
    this.productName = "Pen";
    this.productDetails = 'Detalis';
    this.productPrice = 100;
    
     this.ControlId= new FormControl("",Validators.compose([
            Validators.required]));
    this.ControlNames = new FormControl("",Validators.compose([
            Validators.required,Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
      this.ControlDetails= new FormControl("",Validators.compose([
            Validators.required ]));
      this.ControlPrice= new FormControl("",Validators.compose([
            Validators.required]));
    this.formdata = new FormGroup({
      ControlId : this.ControlId,
      ControlNames:this.ControlNames,
      ControlDetails:this.ControlDetails,
      ControlPrice:this.ControlPrice
    });
    this.ControlId.setValue(1);
    this.ControlNames.setValue("Pen");
    this.ControlDetails.setValue("Details");
    this.ControlPrice.setValue(23);
    
  }

  cancelUpdate(){
   // "Cancel update";
  }
  
}
