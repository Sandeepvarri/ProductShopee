import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ProductService} from '../product.service';
import {Subscription} from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
 formdata;
  id: number = 0;
  ControlId: FormControl;
  ControlNames: FormControl;
  ControlDetails: FormControl;
  ControlPrice: FormControl;
  data;
  subscription:Subscription;
  constructor(private s : ProductService,private router: Router) {
  }

  ngOnInit() {
    this.setVals();
  }

  setVals() {
    this.ControlId = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlNames = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
    this.ControlDetails = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlPrice = new FormControl("", [
      Validators.required, Validators.min(1)
    ]);
    this.formdata = new FormGroup({
      ControlId: this.ControlId,
      ControlNames: this.ControlNames,
      ControlDetails: this.ControlDetails,
      ControlPrice: this.ControlPrice
    });
    this.s.upData
       .subscribe(item => { 
        this.ControlId.setValue(item.productId);
        this.ControlNames.setValue(item.productName);
       this.ControlDetails.setValue(item.productDetail);
       this.ControlPrice.setValue(item.productPrice);
        return this.data = item
 })
  }
  Submit(){
    var Updateddata = {
      productId : this.ControlId.value,
      productName : this.ControlNames.value,
      productPrice : this.ControlPrice.value.toString(),
      productDetail : this.ControlDetails.value
    }
    var a;
    this.s.updateProductList(Updateddata).subscribe(obj => {
     // console.log(obj);
      this.s.getUpdatedList(obj);
    });
     this.router.navigate(['']);

   }
   
}
