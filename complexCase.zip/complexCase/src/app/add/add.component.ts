import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';
import { ProductService} from '../product.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  formdata;
  id: number = 0;
  ControlId: FormControl;
  ControlNames: FormControl;
  ControlDetails: FormControl;
  ControlPrice: FormControl;
  data;
  subscription:Subscription;
  productList;
  existFlag = false;
  constructor(private s : ProductService,private router: Router) {
  }

  ngOnInit() {
    this.setVals();
     this.s.getProductList().subscribe((product: any[]) =>
     { this.productList = product 
      console.log(product);
    });

    this.s.productDetails.subscribe((product: any[]) => 
    {
    this.productList = product
    });
    
  }

  setVals() {
    this.ControlId = new FormControl("", Validators.compose([
      Validators.required,Validators.min(1),Validators.max(9999)]));
    this.ControlNames = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
    this.ControlDetails = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlPrice = new FormControl("", [
      Validators.required, Validators.min(1)
    ]);
    this.formdata = new FormGroup({
      ControlId: this.ControlId,
      ControlNames: this.ControlNames,
      ControlDetails: this.ControlDetails,
      ControlPrice: this.ControlPrice
    });
   
  }
addForm(){
  console.log(this.productList);
 var addData = {
      productId : this.ControlId.value,
      productName : this.ControlNames.value,
      productPrice : this.ControlPrice.value.toString(),
      productDetail : this.ControlDetails.value
    }
  
    this.s.addNewProduct(addData).subscribe(obj => {
     // console.log(obj);
      this.s.getUpdatedList(obj);
    });

    this.router.navigate(['']);
}
onSearchChange(searchValue : string ) {  

for(var obj of this.productList){
  if(obj.productId.toString()==searchValue){
    this.existFlag = true;
    break;
  }
  else{
    this.existFlag = false;
  }
}
}
}
