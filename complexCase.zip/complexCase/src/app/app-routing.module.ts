import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ViewComponent} from './view/view.component'
import {UpdateComponent} from './update/update.component';
import {AddComponent} from './add/add.component'

const routes: Routes = [
  { path: 'view', component: ViewComponent },
  { path: 'update', component: UpdateComponent },
  { path: 'add', component: AddComponent },
];

@NgModule({
  exports: [ RouterModule ],
  declarations: [],
  imports: [ RouterModule.forRoot(routes) ],
})

export class AppRoutingModule { }
