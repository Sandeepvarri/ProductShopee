var fs = require('fs')
var http = require('http');
var express = require('express');
var app = express();
var parser = require('body-parser');
var cors= require('cors');
app.use(parser.json())

// Add headers
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    //res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.route('/getAllProducts',cors()).get((req, res) => {
    var dat = JSON.parse(fs.readFileSync('products.json'));
    console.log("getAllProducts Called");
    console.log(dat);
    res.send(dat)
})


app.route('/updateProduct', cors()).put((req, res) => {
    console.log('update called');
    var mylist = req.body;
    var id = mylist.productId;
    var name = mylist.productName;
    var price = mylist.productPrice;
    var desc = mylist.productDetail;
    var dat = JSON.parse(fs.readFileSync('products.json'));
    for (var p of dat) {
        if (p.productId == id) {
            p.productName = name;
            p.productPrice = price;
            p.productDetail = desc;
            break;
        }
    }
     fs.writeFileSync('products.json', JSON.stringify(dat));
     var dat2 = JSON.parse(fs.readFileSync('products.json'));
    res.send(dat);
})

app.route('/addNewProduct', cors()).post((req, res) => {
    console.log("addNewProduct called");
    var mylist = req.body;
    var p = {
        "productId": mylist.productId,
        "productName": mylist.productName,
        "productPrice": mylist.productPrice,
        "productDetail": mylist.productDetail
    }
    var dat = JSON.parse(fs.readFileSync('products.json'));
    dat.push(p); 
    fs.writeFileSync('products.json', JSON.stringify(dat));
    res.send(dat);
})

app.route('/deleteProduct', cors()).post((req, res) => {
    console.log("deleteProduct called");
    var delObj = req.body;
    console.log(delObj.productId);
     var dat = JSON.parse(fs.readFileSync('products.json'));
    var p
    for (p in dat) {
        if (dat[p].productId == delObj.productId) {
            dat.splice(p, 1);
            break;
        }
    }
    fs.writeFileSync('products.json', JSON.stringify(dat));
    res.send(dat);
})

app.delete('/deleteAll',function(req,res){
    
     fs.writeFileSync('products.json', JSON.stringify([]));
     console.log("All Deleted");
     res.send();
})

app.listen(2200, (err, res) => {
    if (err) throw err;
    console.log("Server started");
})