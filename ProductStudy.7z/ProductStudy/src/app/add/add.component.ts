import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';
import { ServiceService } from "../service.service";

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private s:ServiceService) { }
   Id:number;
   name:string;
   des:string;
   price:number;



  ngOnInit():void {
  
 
}

checkPrice(){
  if(this.price>0) {console.log("true");return true;}
  return false;
}

addForm(){
  this.s.addNewProduct(this.Id,this.name,this.price,this.des);
}

}