export interface Product {
    productId:number,
    productName:String,
    productPrice:number,
    productDetail:String
}
