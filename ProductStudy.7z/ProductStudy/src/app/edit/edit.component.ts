import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from "../service.service";
import { Product } from '../product';
import {Location } from '@angular/common'
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  formdata;
  id: number = 0;
  ControlId: FormControl;
  ControlNames: FormControl;
  ControlDetails: FormControl;
  ControlPrice: FormControl;

  constructor(private route: ActivatedRoute,private l : Location, private s: ServiceService) {
  }

  ngOnInit() {
    this.getId();
    this.setVals();
  }

  getId(): void {
    this.id = +this.route.snapshot.paramMap.get('id');
  }

  setVals() {
    this.ControlId = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlNames = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
    this.ControlDetails = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlPrice = new FormControl("", [
      Validators.required, Validators.min(1)
    ]);
    this.formdata = new FormGroup({
      ControlId: this.ControlId,
      ControlNames: this.ControlNames,
      ControlDetails: this.ControlDetails,
      ControlPrice: this.ControlPrice
    });
    this.s.getOneProd(this.id).subscribe((data: Product) => {
      this.ControlId.setValue(data.productId);
      this.ControlNames.setValue(data.productName);
      this.ControlDetails.setValue(data.productDetail);
      this.ControlPrice.setValue(data.productPrice);
    });

  }

  Submit(){
    this.s.updateProduct(this.ControlId.value,this.ControlNames.value,this.ControlPrice.value,this.ControlDetails.value).subscribe();
    this.l.replaceState("");
    
  }

}
