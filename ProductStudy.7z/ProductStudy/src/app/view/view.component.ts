import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Product } from '../product';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  noOfButtons;
  noOfButtonsArray = [];
  p: number = 1;

  productList:Product[] = [];
  constructor(private s: ServiceService) { 
    this.getProductlist();    
  }

  getProductlist(): void {
    this.s.getProductList().subscribe((product: Product[]) => this.productList = product);
  }

  ngOnInit() {
    
  }

  del(id:number){
    console.log("Delete button clicked for ID : "+id);
    this.s.deleteProduct(id).subscribe((product: Product[]) => this.productList = product);
  }

}
