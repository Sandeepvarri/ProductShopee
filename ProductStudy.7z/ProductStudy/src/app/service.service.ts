import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClient) { }

  getProductList(){
    return this.http.get<Product[]>('http://localhost:2200/getAllProducts');
  }

  addNewProduct(id:number,name:string,price:number,desc:string){
    var url="http://localhost:2200/addNewProduct/"+id+"/"+name+"/"+price+"/"+desc;
    return this.http.post(url,{});
  }

  deleteProduct(id:number){
    var url="http://localhost:2200/deleteProduct/"+id;
    return this.http.delete(url);
  }

  updateProduct(id:number,name:string,price:number,desc:string){
    var url="http://localhost:2200/updateProduct/"+id+"/"+name+"/"+price+"/"+desc;
    return this.http.put(url,{});
  }

  getOneProd(id:number){
    var url="http://localhost:2200/getOneProduct/"+id;
    return this.http.get(url);
  }

}