var fs = require('fs')
var http = require('http');
var express = require('express');
var app = express();
var parser = require('body-parser');
var cors= require('cors');
app.use(parser.json())

// Add headers
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    //res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.route('/getAllProducts',cors()).get((req, res) => {
    var dat = JSON.parse(fs.readFileSync('products.json'));
    console.log("getAllProducts Called");
    res.status(200).send(dat)
})

app.route('/getOneProduct/:id', cors()).get((req, res) => {
    var dat = JSON.parse(fs.readFileSync('products.json'));
    var id = req.params["id"];
    console.log("getOneProduct Called");
    for (var p of dat) {
        if (p.productId == id) {
            res.status(200).send(p);
            break;
        }
    }
    
})

app.route('/updateProduct/:id/:name/:price/:desc', cors()).put((req, res) => {
    console.log("updateProduct Called");
    var id = req.params["id"];
    var name = req.params["name"];
    var price = req.params["price"];
    var desc = req.params["desc"];
    var dat = JSON.parse(fs.readFileSync('products.json'));
    for (var p of dat) {
        if (p.productId == id) {
            p.productName = name;
            p.productPrice = price;
            p.productDetail = desc;
            break;
        }
    }
    res.status(200).send(true)
    fs.writeFileSync('products.json', JSON.stringify(dat));
})

app.route('/addNewProduct/:id/:name/:price/:desc', cors()).post((req, res) => {
    console.log("addNewProduct called");
    var p = {
        "productId": req.params["id"],
        "productName": req.params["name"],
        "productPrice": req.params["price"],
        "productDetail": req.params["desc"]
    }
    var dat = JSON.parse(fs.readFileSync('products.json'));
    dat.push(p);
    res.status(200).send(true);
    fs.writeFileSync('products.json', JSON.stringify(dat));
})

app.route('/deleteProduct/:id', cors()).delete((req, res) => {
    console.log("deleteProduct called");
    var id = req.params["id"]
    var dat = JSON.parse(fs.readFileSync('products.json'));
    var p
    for (p in dat) {
        if (dat[p].productId == id) {
            dat.splice(p, 1);
            break;
        }
    }
    
    res.status(200).send(dat);
    fs.writeFileSync('products.json', JSON.stringify(dat));
})


app.listen(2200, (err, res) => {
    if (err) throw err;
    console.log("Server started");
})