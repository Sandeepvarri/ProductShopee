import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ProductService} from '../product.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
 formdata;
  id: number = 0;
  ControlId: FormControl;
  ControlNames: FormControl;
  ControlDetails: FormControl;
  ControlPrice: FormControl;
  data;
  constructor(private s : ProductService) {
  }

  ngOnInit() {
    this.setVals();
  }

  setVals() {
    this.ControlId = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlNames = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
    this.ControlDetails = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlPrice = new FormControl("", [
      Validators.required, Validators.min(1)
    ]);
    this.formdata = new FormGroup({
      ControlId: this.ControlId,
      ControlNames: this.ControlNames,
      ControlDetails: this.ControlDetails,
      ControlPrice: this.ControlPrice
    });
   
     this.data=this.s.getUpdateObj();
       this.ControlId.setValue(this.data.productId);
       this.ControlNames.setValue(this.data.productName);
      this.ControlDetails.setValue(this.data.productDetail);
      this.ControlPrice.setValue(this.data.productPrice); 
  

  }

  

  Submit(){
    
   }

}
