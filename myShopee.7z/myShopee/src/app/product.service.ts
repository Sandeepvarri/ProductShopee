import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productDetails;
  upData;
  constructor(private http:HttpClient) {
    this.getProductList();
   }

  getProductList(){
    this.productDetails =  this.http.get<any[]>('http://localhost:2200/getAllProducts');
    console.log(this.productDetails);
    return this.productDetails;
  }

  setUpdateObj(obj){
    this.upData = obj;
  }

  getUpdateObj(){
    return this.upData ;
  }


}
