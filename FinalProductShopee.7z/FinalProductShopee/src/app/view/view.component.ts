import { Component, OnInit } from '@angular/core';
import { ProductService} from '../product.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  p: number = 1;

  productList:any[] = [];
  constructor(private s : ProductService,private router: Router) { 
    this.s.productDetails.subscribe((product: any[]) => 
    {console.log("view",product)
    this.productList = product
    console.log(this.productList);
    });
       
  }

  getProductlist(): void {
    
     this.s.getProductList().subscribe((product: any[]) => this.productList = product);
     
  }

  ngOnInit() {
    this.getProductlist(); 
  }

  edit(prod){
    this.router.navigate(['update']);
    this.s.setUpdateObj(prod);
  }
  del(id:number){
    this.s.deleteProduct(id).subscribe((product: any[]) => this.productList = product);

  }
  DeleteAll(){
   var del = confirm("Are you sure you want to Delete All Products!??")
     if(del){
     this.s.deleteAll().subscribe((product: any[]) => this.productList = []);
     }
  }
  
}
