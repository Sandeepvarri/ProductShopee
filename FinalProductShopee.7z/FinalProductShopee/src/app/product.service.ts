import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {BehaviorSubject} from 'rxjs';
import {Subscription} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  constructor(private http:HttpClient) {
    this.getProductList();
   }
   private _navItemSource = new BehaviorSubject<any>({});
   upData = this._navItemSource.asObservable();

   private _navItemSource2 = new BehaviorSubject<any>([{}]);
   productDetails  = this._navItemSource2.asObservable();

  getProductList():Observable<any[]>{
    var get = this.http.get('http://localhost:2200/getAllProducts')
    return get;
  }

  setUpdateObj(obj){
    this._navItemSource.next(obj);
  }
  
  getUpdatedList(obj){
    this._navItemSource2.next(obj);
  }

  updateProductList(data){
    var url="http://localhost:2200/updateProduct";
    var newdata = this.http.put<any[]>(url,data);
    return newdata;
  }

 addNewProduct(data): Observable<any[]>{
   console.log(data);
    var url="http://localhost:2200/addNewProduct";
    return this.http.post(url,data);
  }

   deleteProduct(id:number): Observable<any[]>{
     var delId = {productId : id};
    var url="http://localhost:2200/deleteProduct";
    return this.http.post(url,delId);
  }

  deleteAll(){
   var url="http://localhost:2200/deleteAll";
    return this.http.delete(url);
  }

}
