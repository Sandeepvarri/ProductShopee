import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';
import { ProductService} from '../product.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  formdata;
  id: number = 0;
  ControlId: FormControl;
  ControlNames: FormControl;
  ControlDetails: FormControl;
  ControlPrice: FormControl;
  data;
  subscription:Subscription;
  constructor(private s : ProductService,private router: Router) {
  }

  ngOnInit() {
    this.setVals();
  }

  setVals() {
    this.ControlId = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlNames = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[A-Z]+[a-zA-Z0-9 ]*")]));
    this.ControlDetails = new FormControl("", Validators.compose([
      Validators.required]));
    this.ControlPrice = new FormControl("", [
      Validators.required, Validators.min(1)
    ]);
    this.formdata = new FormGroup({
      ControlId: this.ControlId,
      ControlNames: this.ControlNames,
      ControlDetails: this.ControlDetails,
      ControlPrice: this.ControlPrice
    });
    
  }
addForm(){
 var addData = {
      productId : this.ControlId.value,
      productName : this.ControlNames.value,
      productPrice : this.ControlPrice.value.toString(),
      productDetail : this.ControlDetails.value
    }
  
    this.s.addNewProduct(addData).subscribe(obj => {
     // console.log(obj);
      this.s.getUpdatedList(obj);
    });

    this.router.navigate(['']);
}
}
